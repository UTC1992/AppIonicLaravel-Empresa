<?php

use Faker\Generator as Faker;

$factory->define(App\Models\OrdenTemp::class, function (Faker $faker) {
    return [
        //
    ];
});
