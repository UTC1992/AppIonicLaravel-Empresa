<?php

use Faker\Generator as Faker;

$factory->define(App\Models\Tecnico::class, function (Faker $faker) {
    return [
        //
    ];
});
