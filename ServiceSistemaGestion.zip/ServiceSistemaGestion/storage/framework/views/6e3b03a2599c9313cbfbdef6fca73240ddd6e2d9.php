<?php $__env->startSection('content'); ?>

  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Historial de acciones
      <small>Inicio</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="/admin"><i class="fa fa-home"></i>Inicio</a></li>
      <li class="active">Aquí</li>
    </ol>
  </section>
  <br>
  <div class="">
    <div class="col-md-12">
        <div class="box box-primary box-body form-horizontal">
            <form method="post" action="/historial/inicio">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label class="control-label col-lg-2">Empresa:</label>
                    <div class="col-md-3">
                        <select class="form-control" name="id_emp" required>
                            <option value="">--Seleccionar--</option>
                            <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id_emp); ?>"><?php echo e($item->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <label class="control-label col-lg-2">Fecha de Inicio:</label>
                    <div class="col-md-3">
                        <input type="date" class="form-control" name="fecha_actividad" value="" required>
                    </div>
                    <button type="submit" class="btn btn-primary" >
                        Buscar
                    </button>
                </div>

            </form>
        </div>

      <div class="box">
          <div class="box-header with-border">
              <h3 class="box-title"><b>Acciones realizadas</b></h3>
          </div>
          <!-- /.box-header -->
          <div class="box-body">
              <div class="table-responsive">
                  <table id="tablaDinamica" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                          <th>
                              Acción
                          </th>
                          <th>
                              Observacióm
                          </th>
                          <th>
                              Usuario
                          </th>
                          <th>
                              Módulo
                          </th>
                          <th>
                              Fecha
                          </th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $historiales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($item->accion); ?>

                            </td>
                            <td>
                                <?php echo e($item->observacion); ?>

                            </td>
                            <td>
                                <?php echo e($item->nombre); ?>

                            </td>
                            <td>
                                <?php echo e($item->modulo); ?>

                            </td>
                            <td>
                                <?php echo e($item->created_at); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
              </div>
          </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>