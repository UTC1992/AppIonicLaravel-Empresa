<?php $__env->startSection('content'); ?>
  
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Gestión de subscripciones
      <small>Inicio</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="/admin"><i class="fa fa-home"></i>Inicio</a></li>
      <li class="active">Aquí</li>
    </ol>
  </section>
  <br>
  <div class="">
    <div class="col-md-12">
      <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-default">
        Nueva Subscripción
      </button>
      <br />
      <br />
      <div class="box">
          <div class="box-header with-border">
              <h3 class="box-title"><b>Lista de subscripciones</b></h3>
          </div>
          <!-- /.box-header -->
          <div class="box-body">
              <div class="table-responsive">
                  <table id="tablaDinamica" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                          <th>
                              Empresa
                          </th>
                          <th>
                              Módulo
                          </th>
                          <th>
                              Plan
                          </th>
                          <th>
                              # Usuarios
                          </th>
                          <th>
                              Inicio
                          </th>
                          <th>
                              Finalización
                          </th>
                          <th>
                              Acciones
                          </th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $subs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                          <td>
                              <?php echo e($item->nombreEmp); ?>

                          </td>
                          <td>
                              <?php echo e($item->nombreMod); ?>

                          </td>
                          <td>
                              <?php echo e($item->nombre); ?>

                          </td>
                          <td>
                              <?php echo e($item->num_tecnicos); ?>

                          </td>
                          <td>
                              <?php echo e($item->fecha_inicio); ?>

                          </td>
                          <td>
                              <?php echo e($item->fecha_fin); ?>

                          </td>
                          <td>
                              <a class="btn btn-info btn-xs" href="/subscripcion/edit/<?php echo e($item->id_mod_emp); ?>">Editar</a>
                              <a class="btn btn-danger btn-xs" href="/subscripcion/delete/<?php echo e($item->id_mod_emp); ?>">Eliminar</a>
                          </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
              </div>
          </div>
      </div>
    </div>
  </div>

  <!--MODAL CREAR EMPRESA -->
  <div class="modal fade" id="modal-default" style="display: none; padding-right: 17px;">
    <div class="modal-dialog">
      <div class="modal-content" >
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">Crear una nueva subscripción</h4>
        </div>
        <form method="post" action="/subscripcion/save">
          <?php echo csrf_field(); ?>
            <div class="modal-body">
              <div class="box box-primary">
                  <div class="box-body">
                      <div class="form-horizontal">
                          <div class="form-group">
                              <label class="control-label col-md-2">Empresa:</label>
                              <div class="col-md-8">
                                  <select class="form-control" name="id_emp" required>
                                      <option value="">--Seleccionar--</option>
                                    <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($item->id_emp); ?>"><?php echo e($item->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                              </div>
                          </div>
                          <div class="form-group">
                              <label class="control-label col-md-2">Módulo:</label>
                              <div class="col-md-8">
                                  <select class="form-control" name="id_mod" required>
                                      <option value="">--Seleccionar--</option>
                                    <?php $__currentLoopData = $modulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($item->id_mod); ?>"><?php echo e($item->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                              </div>
                          </div>
                          <div class="form-group">
                              <label class="control-label col-md-2">Planes:</label>
                              <div class="col-md-8">
                                  <select class="form-control" name="id_plan" required>
                                      <option value="">--Seleccionar--</option>
                                    <?php $__currentLoopData = $planes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($item->id_plan); ?>"><?php echo e($item->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                              </div>
                          </div>
                          <div class="form-group">
                            <label class="control-label col-md-2">Fecha de Inicio:</label>
                            <div class="col-md-8">
                                <input type="date" class="form-control" name="fecha_inicio" value="" required>
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="control-label col-md-2">Fecha de Fin:</label>
                            <div class="col-md-8">
                                <input type="date" class="form-control" name="fecha_fin" value="" required>
                            </div>
                          </div>
                      </div>
                  </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-danger pull-left" data-dismiss="modal">Cerrar</button><button type="submit" class="btn btn-primary">Guardar</button>
            </div>
        </form>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <!-- /.modal -->
  <!--MODAL CREAR EMPRESA-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>