<?php $__env->startSection('content'); ?>
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Inicio
      <small>Gestionar</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-home"></i>Inicio</a></li>
      <li class="active">Aquí</li>
    </ol>
  </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>